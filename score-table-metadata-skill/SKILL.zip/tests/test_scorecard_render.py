"""Renderer tests: Markdown stable shape + HTML structural elements."""

from __future__ import annotations

import pytest


@pytest.fixture
def sample_report():
    return {
        "rubric_version": "1.0",
        "scored_at": "2026-05-04T12:00:00+00:00",
        "scope": {"dataset": "my-project.analytics"},
        "tables": [
            {
                "table_id": "my-project.analytics.events",
                "score": 88,
                "grade": "B",
                "table_metadata": {
                    "description": "Application events emitted by the patient portal.\nUsed for engagement analysis.",
                    "labels": {"owner": "engagement-team"},
                    "points": 14, "max": 16,
                    "criteria": [
                        {"name": "business_description", "points": 2, "max": 2, "passed": True, "evidence": "Encounter records..."},
                        {"name": "grain_statement", "points": 2, "max": 2, "passed": True, "evidence": "one row per..."},
                        {"name": "primary_keys", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                        {"name": "join_guidance", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                        {"name": "ownership", "points": 2, "max": 2, "passed": True, "evidence": "label `owner=...`"},
                        {"name": "sensitivity", "points": 2, "max": 2, "passed": True, "evidence": "PHI"},
                        {"name": "history_rule", "points": 1, "max": 2, "passed": False, "evidence": "Use latest_record_ind"},
                        {"name": "lineage", "points": 1, "max": 2, "passed": False, "evidence": ""},
                    ],
                },
                "column_metadata": {
                    "mean_normalized": 0.86, "column_count": 2,
                    "columns": [
                        {
                            "name": "encounter_id", "type": "STRING", "mode": "NULLABLE",
                            "description": "Stable encounter identifier.",
                            "points": 4, "max": 4,
                            "criteria": [
                                {"name": "has_description", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                                {"name": "not_type_echo", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                            ],
                        },
                        {
                            "name": "event_timestamp", "type": "TIMESTAMP", "mode": "NULLABLE",
                            "description": "When the event occurred.",
                            "points": 4, "max": 6,
                            "criteria": [
                                {"name": "has_description", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                                {"name": "not_type_echo", "points": 2, "max": 2, "passed": True, "evidence": "..."},
                                {"name": "units_or_format", "points": 0, "max": 2, "passed": False, "evidence": ""},
                            ],
                        },
                    ],
                },
                "issues": [
                    "No current-state vs. history rule.",
                    "Source system / lineage not mentioned.",
                ],
            },
            {
                "table_id": "my-project.analytics.users",
                "score": 45,
                "grade": "F",
                "table_metadata": {
                    "points": 4, "max": 16,
                    "criteria": [
                        {"name": "business_description", "points": 1, "max": 2, "passed": False, "evidence": "Users table."},
                        {"name": "grain_statement", "points": 0, "max": 2, "passed": False, "evidence": ""},
                        {"name": "primary_keys", "points": 0, "max": 2, "passed": False, "evidence": ""},
                        {"name": "join_guidance", "points": 0, "max": 2, "passed": False, "evidence": ""},
                        {"name": "ownership", "points": 0, "max": 2, "passed": False, "evidence": ""},
                        {"name": "sensitivity", "points": 1, "max": 2, "passed": False, "evidence": ""},
                        {"name": "history_rule", "points": 1, "max": 2, "passed": False, "evidence": ""},
                        {"name": "lineage", "points": 1, "max": 2, "passed": False, "evidence": ""},
                    ],
                },
                "column_metadata": {
                    "mean_normalized": 0.50, "column_count": 1,
                    "columns": [
                        {
                            "name": "user_id", "type": "STRING", "mode": "NULLABLE",
                            "description": "id field",
                            "points": 2, "max": 4,
                            "criteria": [
                                {"name": "has_description", "points": 2, "max": 2, "passed": True, "evidence": "id field"},
                                {"name": "not_type_echo", "points": 0, "max": 2, "passed": False, "evidence": "id field"},
                            ],
                        },
                    ],
                },
                "issues": ["Column `user_id` description just echoes the type/name."],
            },
        ],
        "warnings": [],
    }


class TestMarkdown:
    """Stable text-shape coverage for the Markdown renderer."""

    def test_top_level_header(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert md.startswith("# Metadata Scorecard\n")

    def test_includes_scope(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert "my-project.analytics" in md

    def test_tables_sorted_worst_first(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        users_idx = md.index("my-project.analytics.users")
        events_idx = md.index("my-project.analytics.events")
        assert users_idx < events_idx

    def test_includes_score_and_grade(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert "88/100 (B)" in md
        assert "45/100 (F)" in md

    def test_criterion_status_labels(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert "[pass]" in md and "[fail]" in md and "[partial]" in md

    def test_empty_report_does_not_crash(self, render_module):
        md = render_module.make_markdown({
            "rubric_version": "1.0", "scope": {"tables": []}, "tables": [],
        })
        assert md.startswith("# Metadata Scorecard\n")

    def test_table_description_rendered_as_blockquote(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        # The events table description has two lines
        assert "> Application events emitted by the patient portal." in md
        assert "> Used for engagement analysis." in md

    def test_missing_table_description_marked_as_none(self, render_module):
        md = render_module.make_markdown({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 50, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        assert "_(none)_" in md

    def test_table_labels_rendered(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert "`owner=engagement-team`" in md

    def test_column_table_includes_description_column(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        assert "| Column | Type | Score | Description | Failing criteria |" in md
        assert "Stable encounter identifier." in md

    def test_markdown_summary_section_present(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        # Summary appears before per-table sections
        summary_idx = md.index("## Summary")
        first_table_idx = md.index("`my-project.analytics.users`")
        # The first occurrence of the table id is in the summary table, which precedes the H2 for that table
        # We can assert that the summary header precedes both per-table H2s
        users_h2 = md.index("## `my-project.analytics.users`")
        events_h2 = md.index("## `my-project.analytics.events`")
        assert summary_idx < users_h2 < events_h2

    def test_markdown_summary_includes_table_score_grade_and_top_issue(self, render_module, sample_report):
        md = render_module.make_markdown(sample_report)
        # Summary row format: | `table_id` | score | grade | top issue |
        assert "| `my-project.analytics.users` | 45 | F |" in md
        assert "| `my-project.analytics.events` | 88 | B |" in md

    def test_markdown_summary_dash_when_no_issues(self, render_module):
        md = render_module.make_markdown({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 95, "grade": "A",
                "table_metadata": {"description": "ok", "labels": {}, "points": 16, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 1.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        assert "| `p.d.t` | 95 | A | — |" in md

    def test_pipe_in_evidence_is_escaped(self, render_module):
        md = render_module.make_markdown({
            "rubric_version": "1.0",
            "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 50, "grade": "F",
                "table_metadata": {"points": 0, "max": 16, "criteria": [
                    {"name": "x", "points": 0, "max": 2, "passed": False,
                     "evidence": "a | b | c"},
                ]},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        # Verify the pipe is escaped (so it doesn't break the markdown table)
        assert "a \\| b \\| c" in md


class TestHtml:
    """Structural coverage for the HTML renderer: self-containment, escaping, anchors, theming."""

    def test_self_contained(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert "<style>" in h and "</style>" in h
        assert "<script" not in h
        assert "<link" not in h

    def test_doctype_present(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert h.startswith("<!DOCTYPE html>")

    def test_score_and_grade_rendered(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert ">88<" in h
        assert "grade-B" in h
        assert "grade-F" in h

    def test_pill_status_classes_present(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert "pill pass" in h
        assert "pill fail" in h
        assert "pill partial" in h

    def test_html_escapes_table_id(self, render_module):
        h = render_module.make_html({
            "rubric_version": "1.0",
            "scope": {"tables": ["a&b.c.d<e>"]},
            "tables": [{
                "table_id": "a&b.c.d<e>", "score": 10, "grade": "F",
                "table_metadata": {"points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        assert "a&amp;b.c.d&lt;e&gt;" in h

    def test_theme_auto_includes_both_palettes(self, render_module, sample_report):
        h = render_module.make_html(sample_report, theme="auto")
        assert "prefers-color-scheme: dark" in h

    def test_theme_light_excludes_dark_palette(self, render_module, sample_report):
        h = render_module.make_html(sample_report, theme="light")
        assert "prefers-color-scheme: dark" not in h

    def test_invalid_theme_raises(self, render_module, sample_report):
        with pytest.raises(ValueError):
            render_module.make_html(sample_report, theme="solarized")

    def test_table_description_panel_present(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert 'class="desc-panel"' in h
        assert "Application events emitted by the patient portal." in h
        # Open by default
        assert '<details class="desc-panel" open>' in h

    def test_table_label_chips_rendered(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert 'class="label-chip"' in h
        assert "engagement-team" in h

    def test_column_description_in_collapsible(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert 'class="col-desc"' in h
        assert "Stable encounter identifier." in h

    def test_html_summary_present(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        assert 'class="summary"' in h
        assert ">Summary &middot; 2 table" in h
        assert "<th>Table</th><th>Score</th><th>Grade</th><th>Top issue</th>" in h

    def test_html_summary_links_to_anchor(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        # Anchor IDs derive from the table_id; check both directions
        assert 'id="t-my-project-analytics-users"' in h
        assert 'href="#t-my-project-analytics-users"' in h

    def test_html_summary_precedes_scorecards(self, render_module, sample_report):
        h = render_module.make_html(sample_report)
        summary_idx = h.index('class="summary"')
        first_card_idx = h.index('class="scorecard"')
        assert summary_idx < first_card_idx

    def test_html_summary_dash_for_no_issues(self, render_module):
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 95, "grade": "A",
                "table_metadata": {"description": "ok", "labels": {}, "points": 16, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 1.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        assert "&mdash;" in h

    def test_slug_handles_special_chars(self, render_module):
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["a-b.c.d_e"]},
            "tables": [{
                "table_id": "a-b.c.d_e", "score": 50, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [],
            }],
        })
        assert 'id="t-a-b-c-d-e"' in h

    def test_nested_columns_indent_and_group(self, render_module):
        """Nested columns get margin-left in HTML and stay grouped under their parent."""
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 70, "grade": "C",
                "table_metadata": {"description": "x", "labels": {}, "points": 14, "max": 16, "criteria": []},
                "column_metadata": {
                    "mean_normalized": 0.7, "column_count": 4,
                    "columns": [
                        # Worst-scoring root would normally come first; this verifies that
                        # nested children stay under their parent regardless of sort.
                        {"name": "encounter_id", "type": "STRING", "description": "id",
                         "parent": None, "points": 4, "max": 4, "criteria": []},
                        {"name": "patient", "type": "RECORD", "description": "demographics",
                         "parent": None, "points": 2, "max": 4, "criteria": []},
                        {"name": "patient.email", "type": "STRING", "description": "email",
                         "parent": "patient", "points": 2, "max": 6, "criteria": []},
                        {"name": "patient.first_name", "type": "STRING", "description": "first",
                         "parent": "patient", "points": 4, "max": 4, "criteria": []},
                    ],
                },
                "issues": [],
            }],
        })
        # Nested columns get margin-left applied via inline style.
        assert 'margin-left: 18px' in h  # depth-1 (one dot)
        # The patient leaves render after the patient root, not interleaved with encounter_id.
        patient_idx = h.index('<code>patient</code>')
        email_idx = h.index('<code>patient.email</code>')
        first_name_idx = h.index('<code>patient.first_name</code>')
        encounter_idx = h.index('<code>encounter_id</code>')
        assert patient_idx < email_idx < first_name_idx
        # Worst root (patient: 0.5) sorts before better root (encounter_id: 1.0).
        assert patient_idx < encounter_idx
        # And the encounter_id (better-scoring root) appears AFTER all of patient's leaves.
        assert first_name_idx < encounter_idx

    def test_top_level_columns_unaffected_when_no_nesting(self, render_module):
        """Tables with no nested fields still sort worst-first (existing behavior)."""
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 70, "grade": "C",
                "table_metadata": {"description": "x", "labels": {}, "points": 14, "max": 16, "criteria": []},
                "column_metadata": {
                    "mean_normalized": 0.7, "column_count": 2,
                    "columns": [
                        {"name": "good_col", "type": "STRING", "description": "ok",
                         "parent": None, "points": 4, "max": 4, "criteria": []},
                        {"name": "bad_col", "type": "STRING", "description": "bad",
                         "parent": None, "points": 0, "max": 4, "criteria": []},
                    ],
                },
                "issues": [],
            }],
        })
        bad_idx = h.index('<code>bad_col</code>')
        good_idx = h.index('<code>good_col</code>')
        assert bad_idx < good_idx  # worst-first preserved
        assert 'margin-left:' not in h  # no nested columns => no inline margin

    def test_dict_issues_render_with_suggestion(self, render_module):
        """Dict-shaped issues render their message and a 'Suggested:' line."""
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 40, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [
                    {"criterion": "grain_statement",
                     "message": "No grain statement.",
                     "suggestion": "Add: 'Grain: one row per `id`.'"},
                ],
            }],
        })
        assert "No grain statement." in h
        assert 'class="issue-suggestion"' in h
        assert "Add: &#x27;Grain: one row per `id`.&#x27;" in h

    def test_string_issues_still_render(self, render_module):
        """Backward compat: string-shaped issues continue to render (no suggestion line)."""
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 40, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": ["Plain old string issue."],
            }],
        })
        assert "Plain old string issue." in h
        assert 'class="issue-suggestion"' not in h

    def test_summary_top_issue_uses_message_only(self, render_module):
        """Summary table shows the message, not the (longer) suggestion."""
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 40, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 0, "columns": []},
                "issues": [
                    {"criterion": "grain_statement",
                     "message": "TOP-MESSAGE",
                     "suggestion": "TOP-SUGGESTION"},
                ],
            }],
        })
        # Summary cell contains the message but not the suggestion.
        assert "TOP-MESSAGE" in h
        # Suggestion still appears in the per-table card, but only once (not in summary).
        assert h.count("TOP-SUGGESTION") == 1

    def test_missing_description_marked_empty(self, render_module):
        h = render_module.make_html({
            "rubric_version": "1.0", "scope": {"tables": ["p.d.t"]},
            "tables": [{
                "table_id": "p.d.t", "score": 50, "grade": "F",
                "table_metadata": {"description": None, "labels": {}, "points": 0, "max": 16, "criteria": []},
                "column_metadata": {"mean_normalized": 0.0, "column_count": 1, "columns": [{
                    "name": "x", "type": "STRING", "mode": "NULLABLE", "description": None,
                    "points": 0, "max": 4, "criteria": [],
                }]},
                "issues": [],
            }],
        })
        assert 'desc-body empty' in h
        assert 'col-desc empty' in h
        assert "(no description)" in h
